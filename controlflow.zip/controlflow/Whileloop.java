package controlflow;

public class Whileloop {

	public static void main(String[] args)
	{
		int i=10;
		while (i<=10)
		{
			System.out.println("Row number:"+i);
			i++;
		}
		
		System.out.println("Execution");
	}
}

