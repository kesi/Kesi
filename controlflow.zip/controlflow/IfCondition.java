package controlflow;

public class IfCondition {

	public static void main(String[] args)
	{ 
		int a=10; int b=20;
		if (a<b)
		{
			System.out.println("if body / true body");
		}
		
		System.out.println("If condition program."); 
	}
	
}

