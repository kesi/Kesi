package controlflow;

public class Dowhileloop {

	public static void main(String[] args)
	{
		int i=9;
		do
		{ 
			System.out.println("Executed for No.of Times: "+i);
			i++;
		}
		while (i<=8);
	}
}
