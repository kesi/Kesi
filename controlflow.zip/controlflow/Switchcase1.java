package controlflow;

public class Switchcase1 {
	
	public static void main(String[] args)
	{ 
	String text="Circulus1";
	switch (text)
	{
	case ("Circulus22"):
		System.out.println("Eneterd in case 1");
	break;
	case ("Circulus122"):
		System.out.println("Eneterd in case 2");
	break;
	}
	
	}

}

