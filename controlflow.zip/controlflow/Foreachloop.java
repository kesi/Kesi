package controlflow;

public class Foreachloop{
	public static void main(String args[])
	{
		int arr[]={12,13,14,44,33,11};
		System.out.println("the lenght is: "+arr.length);
		for(int i:arr)
		{
			System.out.println(i);
			}
	}
}