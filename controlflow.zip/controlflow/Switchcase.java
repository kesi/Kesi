package controlflow;

public class Switchcase {
	
	public static void main(String[] args)
	{ char i='j';
	switch (i)
	{
	default: System.out.println("ubantu"); 
	case 10: System.out.println("Android"); 
	
	case 20: System.out.println("iOS"); 
	case 97: System.out.println("Macintosh"); 
	
	
	}
	}

}

