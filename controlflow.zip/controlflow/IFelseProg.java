package controlflow;

public class IFelseProg {
	public static void main(String[] args)
	{
		
	String a="Hello", b="Hello23"; 
	if (a==b)
	{ System.out.println("if body / true body"); }
	else
	{ System.out.println("else body/false body "); }

}
	}


